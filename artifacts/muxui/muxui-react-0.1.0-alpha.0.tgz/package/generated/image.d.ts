// @generated-from: packages/react/src/supplemental/image.d.ts
// @generated-content-sha256: sha256:d9e982b9c96d6c8335bc128f91f9d53f46d8bcbeaac8223ec09e44051994acdc
import type * as React from 'react';

export type ImageRadius = 'none' | 'sm' | 'md' | 'lg' | 'full';
export type ImageFit = 'cover' | 'contain' | 'fill' | 'none';
export type ImageProps = Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'alt' | 'className'> & {
  alt: string;
  fallbackSrc?: string;
  fallbackSrcSet?: string;
  radius?: ImageRadius;
  fit?: ImageFit;
  className?: string;
};

export declare const Image: React.ForwardRefExoticComponent<ImageProps & React.RefAttributes<HTMLImageElement>>;
