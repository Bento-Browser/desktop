// @generated-from: packages/react/src/supplemental/select-native.d.ts
// @generated-content-sha256: sha256:2b8fcb8ab41263dad01fd6df2cfc8706ee03f5015a7191f28f7d59c803fd2667
import type * as React from 'react';

export type SelectNativeVisualSize = 'sm' | 'md' | 'lg';
export type SelectNativeProps = Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'className' | 'size'> & {
  label?: React.ReactNode;
  description?: React.ReactNode;
  errorMessage?: React.ReactNode;
  invalid?: boolean;
  required?: boolean;
  disabled?: boolean;
  /** String values select Mux control targets; positive numbers pass to native select size. */
  size?: SelectNativeVisualSize | number;
  className?: string;
};

export declare const SelectNative: React.ForwardRefExoticComponent<SelectNativeProps & React.RefAttributes<HTMLSelectElement>>;
