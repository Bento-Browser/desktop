// @generated-from: packages/react/src/supplemental/avatar.d.ts
// @generated-content-sha256: sha256:71852cab7df17f381d28fbbc852624ee302a42957e9d58b9c4a3d423584d29d0
import type * as React from 'react';

export type AvatarSize = 'sm' | 'md' | 'lg';
export type AvatarRootProps = React.HTMLAttributes<HTMLSpanElement> & { size?: AvatarSize; children?: React.ReactNode };
export type AvatarImageProps = Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'alt' | 'className'> & { alt?: string; className?: string };
export type AvatarFallbackProps = React.HTMLAttributes<HTMLSpanElement>;

export declare const Avatar: {
  Root: React.ForwardRefExoticComponent<AvatarRootProps & React.RefAttributes<HTMLSpanElement>>;
  Image: React.ForwardRefExoticComponent<AvatarImageProps & React.RefAttributes<HTMLImageElement>>;
  Fallback: React.ForwardRefExoticComponent<AvatarFallbackProps & React.RefAttributes<HTMLSpanElement>>;
};
